#include <iostream>
#include <string>
#include <vector>
#include "Employee.h"
#include "HourlyEmployee.h"
#include "SalariedEmployee.h"

//function prototypes
void getInput(vector <Employee*>& Ve);
void printList(const vector<Employee*>& Ve);

using namespace std;

int main()
{
	//vector VEmp
	vector <Employee*> VEmp;
	getInput(VEmp);
	printList(VEmp);

	cout << "\nLab 7 completed by: " << "Lume Enahoro" << endl;

	system("pause");
	return 0;
}

//function that adds elements to the vector Ve and prompts the user 
void getInput(vector <Employee*>& Ve)
{

	//variables
	constexpr int HOURLY{ 1 };
	constexpr int SALARIED{ 2 };
	constexpr int STOP{ 3 };
	int id;
	double hours;
	double payRate;
	double salary;
	int choice;

	do
	{
		//Displays the choices
		cout <<"\nEnter 1 for Hourly Employee"
			<< "\nEnter 2 for Salaried Employee"
			<< "\nEnter 3 to stop:";
			cin >> choice;

			while (cin.fail())
			{
				cin.clear();// clears the error or resets the fail bit
				cin.ignore(32767, '\n');// clears the input buffer, the number stands for amount of bytes
				cout << "Invalid choice! Try again: ";
				cin >> choice;
			}

			switch(choice)
			{
			case HOURLY:
				//prompt the user 
				cout << "\nEnter the ID: ";
				cin >> id;

				cout << "Enter the number of hours worked: ";
				cin >> hours;

				cout << "Enter the pay rate: ";
				cin >> payRate;

		// dynamically construct a HourlyEmployee object and
		// push back into vector
				Ve.push_back(new HourlyEmployee(id, hours, payRate));

				break;

			case SALARIED:
				cout << "\nEnter the ID: ";
				cin >> id;

				cout << "Enter the salary: ";
				cin >> salary;

		// dynamically construct a SalariedEmployee object and
		// push back into vector
				Ve.push_back(new SalariedEmployee(id, salary));

				break;

			case STOP:
			
				break;
			}


	} while (choice != STOP);
}

//function to print out Ve elements
void printList(const vector<Employee*> & Ve)
{
	for (int i = 0; i < Ve.size(); i++)
	{
		Ve[i]-> printPay();
	}


}