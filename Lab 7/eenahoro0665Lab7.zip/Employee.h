#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>

using namespace std;

//base class
class Employee
{
private:
	int empID;

public:
	//constructor that takes an int id and assigns it to empID
	Employee(int id)
	{
		empID = id;
	}

	//Function Accessor 
	int getEmpID() const;

	//pure virtual function
	virtual void printPay() = 0;

};
#endif