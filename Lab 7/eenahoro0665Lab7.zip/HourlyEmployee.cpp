#include "HourlyEmployee.h"
#include <iomanip>

//function Accesor that retrieves the hours
double HourlyEmployee::getHours() const
{
	return hours;
}

//function Accessor that retrieves the payRate
double HourlyEmployee::getPayRate() const
{
	return payRate;
}

//function that displays a statement
 void HourlyEmployee::printPay()
{
	 cout << setprecision(2) << showpoint << fixed << endl;
	 double weeklyPay = hours * payRate;
	 cout << "The pay for the hourly employee with ID number " << getEmpID() << " is $" << weeklyPay << endl;
}
