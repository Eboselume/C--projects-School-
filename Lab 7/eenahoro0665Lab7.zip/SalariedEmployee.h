#ifndef SALARIEDEMPLOYEE_H
#define SALARIEDEMPLOYEE_H
#include "Employee.h"
#include <iostream>

using namespace std;

//derived class
class SalariedEmployee : public Employee
{
private: 
	double salary;

public:
	// Constructor that will take in two arguments: The employee id and the salary.
	SalariedEmployee(int empID, double salary):
		Employee(empID)
	{
		this->salary = salary;
	}

	//function Accessor
	double getSalary() const;

	//override function
	void printPay();

	
};


#endif
