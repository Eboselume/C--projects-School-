#include "Employee.h"

//function Accessor retrieves the empID
int Employee::getEmpID() const
{
	return empID;
}
