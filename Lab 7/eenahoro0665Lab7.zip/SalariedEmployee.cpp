#include "SalariedEmployee.h"
#include <iomanip>
#include<iostream>

using namespace std;

//function Accessor that retrieves the salary
double SalariedEmployee::getSalary() const
{
	return salary;
}

//overriden function
void SalariedEmployee::printPay()
{
	cout << setprecision(2) << fixed << endl;
	double weeklyPay = salary / 52;
	cout << "The pay for the salaried employee with ID number " << getEmpID() << " is $ " << weeklyPay << endl;
}


