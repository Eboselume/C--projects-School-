#ifndef HOURLYEMPLOYEE_H
#define HOURLYEMPLOYEE_H
#include <iostream>
#include "Employee.h"

using namespace std;

//derived class
class HourlyEmployee : public Employee
{
private:
	double hours;
	double payRate;

public:
	//constructor that takes three arguments
	HourlyEmployee(int empID,double hours, double payRate):
		Employee(empID)
	{
		this->hours = hours;
		this->payRate = payRate;
	}

	//function Accessor
	double getHours() const;

	//function Accessor
	double getPayRate() const;

	//override function
	 void printPay();


};


#endif